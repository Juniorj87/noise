# Noise Hub — выпуск Workflows

Проверка исходников: 7 октября 2026. На noisesui.vercel.app этот выпуск **не опубликован**. Проверка интеграций и интерфейса не является независимым аудитом безопасности протоколов.

## Главное изменение: цельный сценарий

Новая вкладка **Workflows** объединяет выбор исходного актива, рынка, review, симуляцию, подпись пользовательским кошельком, подтверждение по digest, позиции и вывод.

- **Suilend / NAVI / Kai:** обмен через Cetus Aggregator → депозит фактически полученного Coin в одном атомарном PTB. Если актив уже совпадает — депозит без обмена. При провале команды нет завершённого обмена без депозита, но gas может быть списан.
- Депозит использует настоящий output Coin, а не оценку quote или предполагаемый баланс кошелька.
- После подтверждения обновляются балансы и позиции. Отдельная кнопка вывода выбирает принадлежащую кошельку позицию и свежий доступный объём.
- **Вывод — отдельная проверяемая транзакция.** Автоматическое снятие/обратный swap, universal loop и управление позициями всех протоколов не обещаются.
- Для lending показаны debt/health с источником; health разных протоколов нельзя считать единым risk-score. Отсутствие долга не исключает smart-contract/ликвидностный риск. Kai показывает vault shares и текущую оценку underlying, а не гарантированный redemption.

### Защита границы исполнения

Exact u64/BigInt и on-chain decimals; сверка типа актива; market/position ownership; свежая полная симуляция перед review и ещё одна перед wallet call. Изменение формы/кошелька инвалидирует bytes. Quote review истекает через 60 секунд. NAVI withdraw/borrow теперь добавляют oracle/Pyth updates через официальный SDK, без молчаливого игнорирования ошибки.

Receipt сверяет ожидаемый digest, настоящий sender и effects success. Ответ кошелька сам по себе не считается подтверждением. Журнал сохраняется до wallet prompt; pending/unknown нельзя слепо отправлять повторно. LocalStorage содержит digest/status и контекст восстановления, не подписываемые bytes или ключи. При изменении account данные не переносятся на другой кошелёк.

## Токены

18 curated mainnet активов: SUI, USDC, DEEP, WAL, NS, IKA, SEND, AUSD, USDSUI, SUIUSDE, XBTC, USDT, WUSDC, WUSDT, WETH, WBTC, CETUS, NAVX. Проверяются CoinMetadata и decimals; ticker не заменяет coin type. Это **не рейтинг капитализации** и не все существующие токены Sui. Наличие токена не гарантирует рынок каждого lending-провайдера или текущую ликвидность DEX.

## Возвращённые вкладки

**SuiPump:** живой список indexer API, поиск по имени/ticker/full type/curveId, сортировки, Show more, graduation и pool pending. Во время проверки API вернул 684 записи — число меняется. Метрики indexer не независимо проверены. Для graduated используется live price, не прежняя цена bonding curve. Детали показывают полную идентичность токена и предлагают проверить on-chain metadata и реальный DEX route внутри Noise. **Нативная покупка/продажа bonding curve не реализована и не рекламируется.** Документация: https://suipump.org/integrations .

**Leaderboard:** рейтинг количества подтверждённых Noise Workflows, чьи digest были подготовлены backend и совпали с успешным Sui receipt. Атомарный swap+deposit считается одной операцией. Не рейтингуется весь блокчейн, клики или кошельки без подтверждений. Периоды используют timestamp блокчейна. Место не обещает денежной награды.

**Referral:** ссылка на текущий origin сайта, постоянный собственный code, явное подтверждение inviter. Регистрация и атрибуция требуют проверяемой personal-message подписи владельца. Nonce одноразовый, 5 минут, привязан к wallet/action/code. Блокируются чужая подпись, подмена code, self-referral, повторная атрибуция и транзитивные циклы. Production PostgreSQL операции сериализованы транзакцией/advisory lock. Реальные счётчики invited/active/confirmed workflows после атрибуции. **Revenue sharing и выплаты не настроены**: нет ложного earnings-баланса или Claim. Это не подпись финансовой транзакции.

**AI Assistant:** backend читает действительные доступные balances/positions/markets, APR/APY и ошибки источников. Без ключа/model действует явно помеченный tools-only ответ, не имитация LLM. Для Gemini нужны server-only GOOGLE_AI_API_KEY и AI_MODEL, AI_PROVIDER=gemini. Модель задаётся сервером; клиент не меняет её и не вводит system-history. AI не подписывает, не исполняет сделку и не принимает private keys. Реальных вызовов Gemini/OpenAI с пользовательским ключом не было: протестированы адаптеры с mock HTTP и живые read-only tools. Optional memory требует отдельного ownership session/согласия и production DB; не проверялась как production E2E.

## Проверки этого выпуска

- 264/264 автоматических теста, включая workflow precision, ownership, receipt mismatch, unknown/pending, model boundary, настоящие подписи временных тестовых ключей для Referral и циклы атрибуции.
- 19/19 live integration tests повторно прошли (read-only/build validation/zero-wallet); это не funded signing E2E.
- Сборка: 60 serverless-модулей импортируются; inline scripts четырёх HTML проверены. Dependencies не менялись относительно предыдущего clean install (0 известных npm vulnerabilities на том снимке; не независимый security audit).
- `journey-execution.json`: 18 on-chain metadata; **6/6** unsigned enter simulations — SUI deposit и SUI→USDC→deposit для каждого Suilend/NAVI/Kai; **16/16** SUI→дополнительный asset quotes, включая WAL/NS. Quotes не доказывают funded execution каждого токена.
- `journey-exits.json`: **3/3** unsigned primitive roundtrips: Suilend и NAVI deposit→partial withdrawal, Kai deposit→full share redeem. Suilend test создаёт zero-debt obligation внутри того же PTB и только в тесте пропускает refresh; production existing-position helper refresh включён. Это не вывод из существующей пользовательской позиции с долгом.
- `journey-receipts.json`: проверен настоящий публичный chain receipt и отклонён чужой sender. Неподготовленный Noise digest не получил ranking credit. Это read-only, не наша подписанная end-to-end сделка.
- `referral-http.json`: настоящий локальный HTTP challenge/signature/register/attribute/stats на вновь созданных unfunded тестовых ключах; forged signature отклонена, test rows удалены; ключи не сохранены.
- `journey-ui.json` и `ui-journey-*.png`: Workflows empty/review, SuiPump, Leaderboard, AI, Referral при 1440/390 px; изменение amount отключает старый sign; нет pageerror, повторных IDs или body overflow. Исходные чёрно-синие цвета, Inter/Space Grotesk сохранены. API-ошибка не выдаётся за пустой баланс.
- Более ранние read/build/LP/bridge отчёты оставлены как отдельные датированные доказательства, **не как повторная проверка всех операций текущего выпуска**.

## Публичный каталог: 21 scoped запись

Не «все 32 проекта работают». Включены Sui/native staking, Cetus/Aftermath, swap-only Turbos/FlowX/Momentum/Bluefin Spot, DeepBook spot/Predict, NAVI/Suilend/Scallop, Bucket PSM, Haedal/Volo/SpringSui, STEAMM LP, Kai vaults, официальный Wormhole Connect и read-only SuiPump. Scope и исключения — `PUBLIC_COVERAGE.json`. LIVE означает заявленный adapter path, не полное испытание всех функций пользовательскими средствами. Неподключённые perps/options, native Sui bridge и Automation/Skills не возвращены как работающие продукты.

## Мост и комиссия

Самостоятельно размещённый официальный **Wormhole Connect 6.0.0**, mainnet Sui/Ethereum/Arbitrum/Base/Solana, один конец маршрута Sui. Review/sign/recovery — в виджете. Наличие RPC не доказывает любой маршрут; подписанного cross-chain E2E нет. Noise bridge fee = 0.

Default router fee **2 bps = 0,02%** из input asset; quote на net input. Получатель:
`0xa29a8f72981c5644c348a51cd4aded6dbb47ad4361f7a825e19d377e9c4373a1`

Эффективный адрес/ставка доступны в review. Production env/валидная DB config могут их менять, клиент не задаёт получателя. Старый `revision-execution.json` подтверждает 20 000 MIST получателю для 0,1 SUI Cetus swap. Новые atomic routes используют тот же fee leg. Deposit без swap, withdraw, bridge/LP/DeepBook не выдаются за fee-bearing router swaps. Уже полученный доход не подтверждён: последняя проверка адреса показала 0 SUI, это не all-time revenue audit. Referral counts не превращены в доход.

## Что ещё необходимо до публичного запуска

1. Deploy и собственная production PostgreSQL; production connection/schema/concurrency не тестировались с предоставленным DATABASE_URL. Локальный SQLite не заменяет serverless persistence.
2. Gemini key/model в server env, если нужен настоящий разговор с моделью. Ключа в ZIP и browser нет; секреты в чат не отправлять.
3. Самостоятельный небольшой funded-wallet E2E: entry, receipt, повторный вход после reload, existing-position withdrawal, риск/долг и bridge recovery. В этом аудите ни одной финансовой транзакции не подписано/отправлено.
4. Независимый security review, устойчивые RPC limits и monitoring; симуляция не гарантирует безопасность протокола или yield.

Приватный `.env.local` не читался; private env, local DB, node_modules, .git и .vercel в архив не включены.
