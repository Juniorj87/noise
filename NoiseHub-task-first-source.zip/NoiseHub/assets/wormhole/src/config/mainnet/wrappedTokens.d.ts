export declare const MAINNET_WRAPPED_TOKENS: {
    Ethereum: {
        '0xC02aaA39b223FE8D0A0e5C4F27eAD9083C756Cc2': {
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
            Worldchain: string;
        };
        '0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48': {
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Klaytn: string;
            Worldchain: string;
        };
        '0x2260FAC5E5542a773Aa44fBCfeDf7C193bc2C599': {
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Klaytn: string;
            Worldchain: string;
        };
        '0xdAC17F958D2ee523a2206206994597C13D831ec7': {
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Klaytn: string;
            Xlayer: string;
            Worldchain: string;
        };
        '0x6B175474E89094C44Da98b954EedeAC495271d0F': {
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Sui: string;
            Klaytn: string;
            Worldchain: string;
        };
        '0x4Fabb145d64652a948d72533023f6E7A623C7C53': {
            Bsc: string;
            Polygon: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Aptos: string;
            Worldchain: string;
        };
        '0x7f39C581F595B53c5cb19bD0b3f8dA6c935E2Ca0': {
            Polygon: string;
            Solana: string;
            Arbitrum: string;
            Optimism: string;
            Base: string;
            Bsc: string;
            Avalanche: string;
            Fantom: string;
            Worldchain: string;
        };
    };
    Polygon: {
        '0x0d500B1d8E8eF31E21C99d1Db9A6444d3ADf1270': {
            Ethereum: string;
            Bsc: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
            Scroll: string;
            Xlayer: string;
            Worldchain: string;
        };
        '0x7ceB23fD6bC0adD59E62ac25578270cFf1b9f619': {
            Bsc: string;
            Solana: string;
            Aptos: string;
            Sui: string;
            Arbitrum: string;
            Ethereum: string;
            Avalanche: string;
            Optimism: string;
            Fantom: string;
            Base: string;
            Moonbeam: string;
            Celo: string;
            Klaytn: string;
        };
        '0x3c499c542cEF5E3811e1192ce70d8cC03d5c3359': {
            Aptos: string;
            Base: string;
            Moonbeam: string;
            Sui: string;
            Bsc: string;
            Celo: string;
            Fantom: string;
            Avalanche: string;
            Arbitrum: string;
            Optimism: string;
            Solana: string;
            Ethereum: string;
            Klaytn: string;
        };
        '0x03b54A6e9a984069379fae1a4fC4dBAE93B3bCCD': {
            Base: string;
            Arbitrum: string;
            Ethereum: string;
            Optimism: string;
            Celo: string;
        };
    };
    Bsc: {
        '0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c': {
            Ethereum: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
            Scroll: string;
            Xlayer: string;
            Worldchain: string;
        };
        '0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d': {
            Ethereum: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Klaytn: string;
        };
        '0x2170Ed0880ac9A755fd29B2688956BD959F933F8': {
            Aptos: string;
            Solana: string;
            Sui: string;
            Base: string;
            Arbitrum: string;
            Ethereum: string;
            Fantom: string;
            Celo: string;
            Klaytn: string;
            Avalanche: string;
            Optimism: string;
            Polygon: string;
            Moonbeam: string;
        };
    };
    Avalanche: {
        '0xB31f66AA3C1e785363F0875A1B74E27b85FD66c7': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
            Scroll: string;
            Xlayer: string;
            Worldchain: string;
        };
        '0xB97EF9Ef8734C71904D8002F8b6Bc66Dd9c48a6E': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Arbitrum: string;
            Optimism: string;
            Base: string;
            Klaytn: string;
            Scroll: string;
        };
        '0x49D5c2BdFfac6CE2BFdB6640F4F80f226bc10bAB': {
            Aptos: string;
            Solana: string;
            Bsc: string;
            Sui: string;
            Base: string;
            Arbitrum: string;
            Polygon: string;
            Ethereum: string;
            Optimism: string;
            Moonbeam: string;
            Celo: string;
            Klaytn: string;
            Fantom: string;
        };
    };
    Fantom: {
        '0x21be370D5312f44cB42ce377BC9b8a0cEF1A4C83': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
            Scroll: string;
            Xlayer: string;
        };
        '0x2F733095B80A04b38b0D10cC884524a3d09b836a': {
            Bsc: string;
            Arbitrum: string;
            Ethereum: string;
        };
    };
    Celo: {
        '0x471EcE3750Da237f93B8E339c536989b8978a438': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Klaytn: string;
            Worldchain: string;
        };
    };
    Moonbeam: {
        '0xAcc15dC74880C9944775448304B263D191c6077F': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Klaytn: string;
            Scroll: string;
            Xlayer: string;
            Worldchain: string;
        };
    };
    Solana: {
        So11111111111111111111111111111111111111112: {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
            Xlayer: string;
            Scroll: string;
            Worldchain: string;
            Unichain: string;
            Fogo: string;
            Monad: string;
            MegaETH: string;
        };
        EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v: {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Sui: string;
            Aptos: string;
            Arbitrum: string;
            Optimism: string;
            Base: string;
            Klaytn: string;
            Scroll: string;
        };
        HZ1JovNiVvGrGNiiYvEozEVgZ58xaU3RKwX8eACQBCt3: {
            Aptos: string;
            Bsc: string;
            Base: string;
            Celo: string;
            Avalanche: string;
            Polygon: string;
            Fantom: string;
            Optimism: string;
            Ethereum: string;
            Arbitrum: string;
            Sui: string;
            Moonbeam: string;
            Xlayer: string;
            Worldchain: string;
        };
    };
    Sui: {
        native: {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Aptos: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
            Xlayer: string;
            Worldchain: string;
        };
    };
    Aptos: {
        native: {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Base: string;
            Arbitrum: string;
            Optimism: string;
            Klaytn: string;
            Xlayer: string;
            Worldchain: string;
        };
    };
    Arbitrum: {
        '0x82aF49447D8a07e3bd95BD0d56f35241523fBab1': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Base: string;
            Optimism: string;
            Moonbeam: string;
            Klaytn: string;
        };
        '0xaf88d065e77c8cC2239327C5EDb3A432268e5831': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Celo: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Optimism: string;
            Base: string;
            Fantom: string;
            Moonbeam: string;
            Klaytn: string;
            Xlayer: string;
        };
        '0x5979D7b546E38E414F7E9822514be443A4800529': {
            Bsc: string;
            Aptos: string;
            Solana: string;
            Sui: string;
            Base: string;
            Optimism: string;
            Fantom: string;
            Ethereum: string;
            Polygon: string;
        };
    };
    Optimism: {
        '0x4200000000000000000000000000000000000006': {
            Fantom: string;
            Celo: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Arbitrum: string;
            Avalanche: string;
            Bsc: string;
            Ethereum: string;
            Polygon: string;
            Base: string;
            Moonbeam: string;
            Klaytn: string;
        };
        '0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85': {
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Base: string;
            Arbitrum: string;
            Aptos: string;
            Bsc: string;
            Avalanche: string;
            Polygon: string;
            Sui: string;
            Solana: string;
            Klaytn: string;
            Ethereum: string;
        };
        '0x1F32b1c2345538c0c6f582fCB022739c4A194Ebb': {
            Bsc: string;
            Base: string;
            Arbitrum: string;
            Polygon: string;
            Ethereum: string;
        };
    };
    Base: {
        '0x4200000000000000000000000000000000000006': {
            Ethereum: string;
            Bsc: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Celo: string;
            Moonbeam: string;
            Solana: string;
            Sui: string;
            Aptos: string;
            Arbitrum: string;
            Optimism: string;
            Mantle: string;
            Klaytn: string;
        };
        '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913': {
            Solana: string;
            Moonbeam: string;
            Celo: string;
            Bsc: string;
            Optimism: string;
            Arbitrum: string;
            Polygon: string;
            Avalanche: string;
            Fantom: string;
            Sui: string;
            Aptos: string;
            Mantle: string;
            Ethereum: string;
            Klaytn: string;
            Scroll: string;
        };
        '0xc1CBa3fCea344f92D9239c08C0568f6F2F0ee452': {
            Arbitrum: string;
            Ethereum: string;
            Polygon: string;
            Optimism: string;
            Avalanche: string;
        };
    };
    Klaytn: {
        '0xe4f05A66Ec68B54A58B17c22107b02e0232cC817': {
            Aptos: string;
            Ethereum: string;
            Celo: string;
            Polygon: string;
            Base: string;
            Arbitrum: string;
            Moonbeam: string;
            Fantom: string;
            Sui: string;
            Avalanche: string;
            Bsc: string;
            Optimism: string;
            Solana: string;
            Scroll: string;
            Worldchain: string;
        };
    };
    Scroll: {
        '0x5300000000000000000000000000000000000004': {
            Arbitrum: string;
        };
    };
    Mantle: {
        '0x78c1b0C915c4FAA5FffA6CAbf0219DA63d7f4cb8': {
            Optimism: string;
        };
    };
    Monad: {
        '0x3bd359C1119dA7Da1D913D1C4D2B7c461115433A': {
            Solana: string;
        };
    };
};
//# sourceMappingURL=wrappedTokens.d.ts.map